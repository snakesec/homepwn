#ifndef PY2_PKG2_HPP
#define PY2_PKG2_HPP
#include "../../py2/pkg2/pkg3/pkg4/foo.hpp"
struct Pkg2_Bar : Pkg4_Foo {};
#endif /* PY2_PKG2_HPP */

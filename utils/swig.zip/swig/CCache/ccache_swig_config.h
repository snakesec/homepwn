#define SWIG_VERSION "4.0.0"

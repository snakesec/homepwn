#if !defined(PROGRAM_NAME)
#define PROGRAM_NAME "ccache-swig.exe"
#endif
